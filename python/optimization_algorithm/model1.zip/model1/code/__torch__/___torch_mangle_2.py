class JustSigmoid(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  layer : __torch__.torch.nn.modules.container.___torch_mangle_1.Sequential
  def forward(self: __torch__.___torch_mangle_2.JustSigmoid,
    x: Tensor) -> Tensor:
    layer = self.layer
    return (layer).forward(x, )
